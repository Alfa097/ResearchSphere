export default function AIAssistant(){
return <div><h1>Orion AI Assistant</h1></div>
}