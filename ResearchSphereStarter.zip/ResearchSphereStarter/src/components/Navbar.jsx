export default function Navbar(){
return <nav>ResearchSphere</nav>
}